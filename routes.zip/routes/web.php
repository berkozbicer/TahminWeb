<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\PredictionController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Ana Sayfa
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/hakkimizda', [HomeController::class, 'about'])->name('about');
Route::get('/iletisim', [HomeController::class, 'contact'])->name('contact');

// Tahminler (Genel Erişim)
Route::prefix('tahminler')->name('predictions.')->group(function () {
    Route::get('/', [PredictionController::class, 'index'])->name('index');
    Route::get('/bugun', [PredictionController::class, 'today'])->name('today');
    Route::get('/{prediction}', [PredictionController::class, 'show'])->name('show');
});

// Abonelik Paketleri
Route::prefix('abonelik')->name('subscriptions.')->group(function () {
    Route::get('/', [SubscriptionController::class, 'index'])->name('index');

    // Giriş gerektiren rotalar
    Route::middleware('auth')->group(function () {
        Route::get('/yukselt', [SubscriptionController::class, 'upgrade'])->name('upgrade');
        Route::post('/{plan}/abone-ol', [SubscriptionController::class, 'subscribe'])->name('subscribe');
        Route::post('/iptal', [SubscriptionController::class, 'cancel'])->name('cancel');
    });
});

// Kullanıcı Paneli (Auth Required)
Route::middleware('auth')->group(function () {
    Route::get('/panel', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profil', [DashboardController::class, 'profile'])->name('profile');
    Route::put('/profil', [DashboardController::class, 'updateProfile'])->name('profile.update');
    Route::put('/profil/sifre', [DashboardController::class, 'updatePassword'])->name('password.update');
});

// Auth Routes (Laravel Breeze veya Jetstream kullanılacak)
require __DIR__ . '/auth.php';
